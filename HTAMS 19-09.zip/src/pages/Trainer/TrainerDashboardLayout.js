// src/layouts/TrainerDashboardLayout.js
import React, { useState } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import TrainerSidebar from '../../components/TrainerSidebar';
import { FaBars, FaSignOutAlt } from 'react-icons/fa';
import { auth } from '../../firebase/config';
import { signOut } from 'firebase/auth';

const TrainerDashboardLayout = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = async () => {
    try {
      await signOut(auth);
      localStorage.removeItem('htamsUser');
      localStorage.removeItem('trainerStats');
      navigate('/login');
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  // 🌐 Path-to-title mapping for trainer dashboard
  const pageTitles = {
    '/trainer-dashboard': 'Trainer Dashboard',
    '/trainer-dashboard/profile': 'Trainer Profile',
    '/trainer-dashboard/participants': 'Participants',
    // '/trainer-dashboard/trainees': 'Training Management',
    '/trainer-dashboard/applied-users': 'Applied Users',
  };

  // 🧠 Find matching title
  const currentTitle = pageTitles[location.pathname] || 'Trainer Dashboard';

  return (
    <div className="dashboard-container">
      <TrainerSidebar 
        isOpen={isSidebarOpen} 
        toggleSidebar={toggleSidebar}
      />
      <div className="dashboard-main">
        {/* Optional: Uncomment if you want to show page titles */}
        {/* <div className="dashboard-header">
          <h1 className="dashboard-header-title">{currentTitle}</h1>
        </div> */}
        
        <button className="dashboard-mobile-toggle" onClick={toggleSidebar}>
          <FaBars />
        </button>

        <div className="dashboard-content">
          <Outlet />
        </div>
      </div>

      <style jsx>{`
        .dashboard-container {
          display: flex;
          min-height: 100vh;
          background: #f8fafc;
        }

        .dashboard-main {
          flex: 1;
        //   margin-left: ${isSidebarOpen ? '280px' : '70px'};
          transition: margin-left 0.3s ease;
          min-height: 100vh;
          position: relative;
        }

        .dashboard-header {
          background: white;
          padding: 1.5rem 2rem;
          border-bottom: 1px solid #e5e7eb;
          box-shadow: 0 1px 3px rgba(0,0,0,0.1);
          position: sticky;
          top: 0;
          z-index: 10;
        }

        .dashboard-header-title {
          font-size: 1.75rem;
          font-weight: 700;
          color: #1a2332;
          margin: 0;
        }

        .dashboard-mobile-toggle {
          display: none;
          position: fixed;
          top: 1rem;
          left: 1rem;
          z-index: 1002;
          background: #1a2332;
          color: white;
          border: none;
          padding: 0.75rem;
          border-radius: 8px;
          cursor: pointer;
          box-shadow: 0 4px 12px rgba(0,0,0,0.15);
          transition: all 0.3s ease;
        }

        .dashboard-mobile-toggle:hover {
          background: #2d3748;
          transform: translateY(-2px);
        }

        .dashboard-content {
          padding: 2rem;
          min-height: calc(100vh - 2rem);
        }

        @media (max-width: 768px) {
          .dashboard-main {
            margin-left: 0;
            margin-top: 60px;
          }

          .dashboard-mobile-toggle {
            display: block;
          }

          .dashboard-content {
            padding: 1rem;
          }

          .dashboard-header {
            padding: 1rem;
          }

          .dashboard-header-title {
            font-size: 1.5rem;
          }
        }
      `}</style>
    </div>
  );
};

export default TrainerDashboardLayout;
