import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, db } from '../../firebase/config';
import { ref, get, update } from 'firebase/database';
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  sendPasswordResetEmail,
} from 'firebase/auth';
import { FaUser, FaLock, FaEye, FaEyeSlash, FaBuilding, FaSpinner } from 'react-icons/fa';

const LoginPageEmployee = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [isFirstTimeSetup, setIsFirstTimeSetup] = useState(false);

  const navigate = useNavigate();

  // Check if user is already logged in
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      if (user) {
        // Check if user has valid employee data
        const employeeData = localStorage.getItem('employeeData');
        if (employeeData) {
          const parsedData = JSON.parse(employeeData);
          if (parsedData.firstTime === false) {
            navigate('/employee-dashboard', { replace: true });
          }
        }
      }
    });

    return () => unsubscribe();
  }, [navigate]);

  // Enhanced employee verification and auth flow
  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    const cleanEmail = email.trim().toLowerCase();
    const cleanPassword = password.trim();

    // Validation
    if (!cleanEmail || !cleanPassword) {
      setError('❌ Please enter both email and password');
      setLoading(false);
      return;
    }

    try {
      console.log('🔍 Searching for employee in HTAMS/company/Employees...');
      
      // Step 1: Verify employee exists in HTAMS/company/Employees
      const employeeRef = ref(db, 'HTAMS/company/Employees');
      const snapshot = await get(employeeRef);
      
      if (!snapshot.exists()) {
        setError('❌ Company database not accessible. Contact admin.');
        setLoading(false);
        return;
      }

      const employeesData = snapshot.val();
      console.log('📊 Employees data loaded:', Object.keys(employeesData).length, 'employees');
      
      // Find employee by email
      const employeeEntry = Object.entries(employeesData).find(
        ([, emp]) => emp.email?.toLowerCase().trim() === cleanEmail
      );

      if (!employeeEntry) {
        setError('❌ Email not found in company records. Please contact HR.');
        setLoading(false);
        return;
      }

      const [employeeId, employeeData] = employeeEntry;
      console.log('✅ Employee found:', employeeData.name, 'ID:', employeeId);

      // Step 2: Check if employee has Firebase authentication enabled
      if (!employeeData.hasFirebaseAuth) {
        setError('❌ Your account is not enabled for authentication. Contact admin.');
        setLoading(false);
        return;
      }

      // Step 3: Handle first-time login (password should be mobile number)
      if (employeeData.firstTime === true || employeeData.firstTime === undefined) {
        console.log('🔄 First-time login detected for:', employeeData.name);
        
        // For first-time login, password should be mobile number
        if (cleanPassword !== employeeData.mobile) {
          setError(`❌ For first-time login, use your mobile number (${employeeData.mobile}) as password`);
          setLoading(false);
          return;
        }

        // Try to sign in with existing Firebase account or create new one
        try {
          console.log('🔐 Attempting first-time Firebase Auth sign-in...');
          
          const userCredential = await signInWithEmailAndPassword(
            auth,
            employeeData.email.trim(),
            employeeData.mobile
          );

          console.log('✅ First-time sign-in successful');

          // Store employee data
          localStorage.setItem('employeeData', JSON.stringify({
            ...employeeData,
            employeeId,
            uid: userCredential.user.uid
          }));

          // Redirect to set new password
          navigate('/set-new-password');
          return;

        } catch (firstTimeError) {
          console.log('❌ First-time sign-in failed, trying account creation:', firstTimeError.code);
          
          if (firstTimeError.code === 'auth/user-not-found' || firstTimeError.code === 'auth/invalid-credential') {
            // Account doesn't exist, create it
            try {
              console.log('🆕 Creating Firebase Auth account for first-time user...');
              
              const userCredential = await createUserWithEmailAndPassword(
                auth,
                employeeData.email.trim(),
                employeeData.mobile
              );

              // Update profile
              await updateProfile(userCredential.user, {
                displayName: employeeData.name || 'Employee',
              });

              // Update employee record with Firebase UID
              await update(ref(db, `HTAMS/company/Employees/${employeeId}`), {
                firebaseUid: userCredential.user.uid,
                lastLoginAt: new Date().toISOString()
              });

              // Store employee data
              localStorage.setItem('employeeData', JSON.stringify({
                ...employeeData,
                employeeId,
                uid: userCredential.user.uid
              }));

              console.log('✅ Account created successfully, redirecting to set password...');
              
              // Redirect to set new password
              navigate('/set-new-password');
              return;

            } catch (createError) {
              console.error('❌ Account creation failed:', createError);
              
              if (createError.code === 'auth/email-already-in-use') {
                setError('❌ Account exists but password incorrect. Try "Reset Password" or contact admin.');
              } else if (createError.code === 'auth/weak-password') {
                setError('❌ Mobile number too weak as password. Contact admin to set a stronger password.');
              } else if (createError.code === 'auth/operation-not-allowed') {
                setError('❌ Email/password authentication not enabled. Contact admin.');
              } else {
                setError('❌ Account creation failed: ' + createError.message);
              }
              
              setLoading(false);
              return;
            }
          } else {
            // Other authentication errors
            setError('❌ Authentication failed: ' + firstTimeError.message);
            setLoading(false);
            return;
          }
        }
      }

      // Step 4: Regular login attempt for existing users
      try {
        console.log('🔐 Attempting regular login for existing user...');
        
        const userCredential = await signInWithEmailAndPassword(
          auth, 
          employeeData.email.trim(), 
          cleanPassword
        );
        
        console.log('✅ Regular login successful');

        // Update last login time
        await update(ref(db, `HTAMS/company/Employees/${employeeId}`), {
          lastLoginAt: new Date().toISOString()
        });

        // Store employee data
        localStorage.setItem('employeeData', JSON.stringify({
          ...employeeData,
          employeeId,
          uid: userCredential.user.uid
        }));
        
        setError('✅ Login successful! Redirecting...');
        
        // Redirect to dashboard
        setTimeout(() => {
          navigate('/employee-dashboard', { replace: true });
        }, 1000);
        
      } catch (loginError) {
        console.error('❌ Regular login failed:', loginError);
        
        switch (loginError.code) {
          case 'auth/user-not-found':
            setError('❌ No Firebase account found. Contact admin to setup your account.');
            break;
          case 'auth/wrong-password':
            if (employeeData.firstTime === true || employeeData.firstTime === undefined) {
              setError(`❌ For first-time login, use your mobile number: ${employeeData.mobile}`);
            } else {
              setError('❌ Incorrect password. Use "Reset Password" if you forgot it.');
            }
            break;
          case 'auth/invalid-credential':
            setError('❌ Invalid credentials. Check your email and password.');
            break;
          case 'auth/too-many-requests':
            setError('❌ Too many failed attempts. Please wait and try again later.');
            break;
          case 'auth/network-request-failed':
            setError('❌ Network error. Please check your connection.');
            break;
          case 'auth/user-disabled':
            setError('❌ Your account has been disabled. Contact admin.');
            break;
          default:
            setError('❌ Login failed: ' + loginError.message);
        }
      }

    } catch (error) {
      console.error('❌ System error:', error);
      setError('❌ System error. Please try again or contact IT support.');
    }

    setLoading(false);
  };

  // Force first-time setup mode
  const forceFirstTimeSetup = () => {
    setIsFirstTimeSetup(true);
    setError('💡 First-time setup: Enter your email and mobile number as password.');
  };

  // Reset password function
  const resetPassword = async () => {
    if (!email.trim()) {
      setError('❌ Please enter your email first.');
      return;
    }

    setLoading(true);
    
    try {
      // First verify employee exists and check if it's first-time
      const employeeRef = ref(db, 'HTAMS/company/Employees');
      const snapshot = await get(employeeRef);
      
      if (snapshot.exists()) {
        const employeesData = snapshot.val();
        const employeeEntry = Object.entries(employeesData).find(
          ([, emp]) => emp.email?.toLowerCase().trim() === email.trim().toLowerCase()
        );

        if (!employeeEntry) {
          setError('❌ Email not found in company records.');
          setLoading(false);
          return;
        }

        const [, employeeData] = employeeEntry;
        
        // Check if it's a first-time user
        if (employeeData.firstTime === true || employeeData.firstTime === undefined) {
          setError(`💡 For first-time login, use your mobile number: ${employeeData.mobile}`);
          setLoading(false);
          return;
        }
      }

      await sendPasswordResetEmail(auth, email.trim());
      setError('📧 Password reset email sent! Check your inbox.');
      
    } catch (error) {
      console.error('❌ Password reset error:', error);
      
      if (error.code === 'auth/user-not-found') {
        setError('❌ No Firebase account found. Try first-time setup or contact admin.');
      } else if (error.code === 'auth/invalid-email') {
        setError('❌ Invalid email format.');
      } else {
        setError('❌ Reset failed: ' + error.message);
      }
    } finally {
      setLoading(false);
    }
  };

  // Check Firebase configuration
  const checkFirebaseConfig = () => {
    console.log('Firebase Config Check:', {
      apiKey: auth.app.options.apiKey?.substring(0, 10) + '...',
      authDomain: auth.app.options.authDomain,
      projectId: auth.app.options.projectId,
      currentUser: auth.currentUser
    });
    
    if (!auth.app.options.apiKey || !auth.app.options.authDomain) {
      setError('❌ Firebase configuration missing. Check your firebase/config.js file.');
    } else {
      setError('✅ Firebase configuration verified successfully.');
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.loginBox}>
        <div style={styles.header}>
          <FaBuilding style={styles.headerIcon} />
          <h2 style={styles.title}>
            {isFirstTimeSetup ? '🆕 First Time Setup' : '🏢 Employee Login'}
          </h2>
          <p style={styles.subtitle}>
            {isFirstTimeSetup 
              ? 'Enter your email and mobile number as password' 
              : 'Access your employee dashboard'
            }
          </p>
        </div>
        
        <form onSubmit={handleLogin} style={styles.form}>
          <div style={styles.inputGroup}>
            <label style={styles.label}>
              <FaUser style={styles.labelIcon} />
              Email Address
            </label>
            <input
              type="email"
              placeholder="Enter your company email"
              value={email}
              required
              onChange={(e) => {
                setEmail(e.target.value);
                setError('');
              }}
              style={styles.input}
              disabled={loading}
            />
          </div>
          
          <div style={styles.inputGroup}>
            <label style={styles.label}>
              <FaLock style={styles.labelIcon} />
              {isFirstTimeSetup ? 'Mobile Number (as password)' : 'Password'}
            </label>
            <div style={styles.passwordWrapper}>
              <input
                type={showPassword ? 'text' : 'password'}
                placeholder={isFirstTimeSetup 
                  ? "Enter your mobile number" 
                  : "Enter password (mobile number for first-time)"
                }
                value={password}
                required
                onChange={(e) => {
                  setPassword(e.target.value);
                  setError('');
                }}
                style={styles.passwordInput}
                disabled={loading}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                style={styles.eyeButton}
                disabled={loading}
              >
                {showPassword ? <FaEyeSlash /> : <FaEye />}
              </button>
            </div>
            <small style={styles.helpText}>
              {isFirstTimeSetup 
                ? '🔑 Use your mobile number as password for first-time setup'
                : '🔑 First-time users: Use mobile number | Existing users: Use your password'
              }
            </small>
          </div>
          
          <button 
            type="submit" 
            disabled={loading} 
            style={{
              ...styles.submitButton,
              backgroundColor: loading ? '#9CA3AF' : 
                isFirstTimeSetup ? '#10B981' : '#2563EB'
            }}
          >
            {loading ? (
              <span style={styles.loadingContent}>
                <FaSpinner style={styles.spinner} />
                Processing...
              </span>
            ) : (
              isFirstTimeSetup ? '🆕 Setup Account' : '🚀 Login'
            )}
          </button>
          
          <div style={styles.actionButtons}>
            {!isFirstTimeSetup && (
              <button 
                type="button" 
                onClick={forceFirstTimeSetup}
                style={styles.setupButton}
                disabled={loading}
              >
                🆕 First Time?
              </button>
            )}
            
            <button 
              type="button" 
              onClick={resetPassword}
              style={styles.resetButton}
              disabled={loading}
            >
              🔑 Reset Password
            </button>
            
            <button 
              type="button" 
              onClick={checkFirebaseConfig}
              style={styles.configButton}
              disabled={loading}
            >
              🔧 Check Config
            </button>
          </div>
          
          {error && (
            <div style={{
              ...styles.message,
              backgroundColor: error.includes('✅') ? '#D1FAE5' : '#FEE2E2',
              borderColor: error.includes('✅') ? '#10B981' : '#EF4444',
              color: error.includes('✅') ? '#065F46' : '#B91C1C'
            }}>
              {error}
            </div>
          )}
        </form>
        
        <div style={styles.helpSection}>
          <h4 style={styles.helpTitle}>🆘 Quick Help:</h4>
          <div style={styles.quickFixes}>
            <p><strong>🆕 New Employee?</strong> Click "First Time?" and use mobile as password</p>
            <p><strong>👤 Existing User?</strong> Use your email and set password</p>
            <p><strong>🔐 First Login?</strong> Password = Your mobile number</p>
            <p><strong>❓ Technical Issues?</strong> Click "Check Config" then contact IT</p>
          </div>
        </div>

        <div style={styles.footerSection}>
          <p style={styles.footerText}>
            Having trouble? Contact your HR department or IT support.
          </p>
        </div>
      </div>
    </div>
  );
};

const styles = {
  container: {
    minHeight: '100vh',
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '20px',
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
  },
  loginBox: {
    backgroundColor: 'white',
    borderRadius: '16px',
    boxShadow: '0 10px 25px rgba(0,0,0,0.15)',
    padding: '40px',
    width: '100%',
    maxWidth: '500px',
    position: 'relative'
  },
  header: {
    textAlign: 'center',
    marginBottom: '30px'
  },
  headerIcon: {
    fontSize: '3rem',
    color: '#2563EB',
    marginBottom: '16px'
  },
  title: {
    fontSize: '28px',
    fontWeight: '700',
    color: '#1F2937',
    margin: '0 0 8px 0'
  },
  subtitle: {
    fontSize: '16px',
    color: '#6B7280',
    margin: 0,
    lineHeight: '1.5'
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '24px'
  },
  inputGroup: {
    display: 'flex',
    flexDirection: 'column',
    gap: '8px'
  },
  label: {
    fontSize: '14px',
    fontWeight: '600',
    color: '#374151',
    display: 'flex',
    alignItems: 'center',
    gap: '8px'
  },
  labelIcon: {
    fontSize: '14px',
    color: '#6B7280'
  },
  input: {
    width: '100%',
    padding: '12px 16px',
    border: '2px solid #E5E7EB',
    borderRadius: '8px',
    fontSize: '16px',
    boxSizing: 'border-box',
    transition: 'border-color 0.2s ease'
  },
  passwordWrapper: {
    position: 'relative',
    display: 'flex',
    alignItems: 'center'
  },
  passwordInput: {
    width: '100%',
    padding: '12px 50px 12px 16px',
    border: '2px solid #E5E7EB',
    borderRadius: '8px',
    fontSize: '16px',
    boxSizing: 'border-box',
    transition: 'border-color 0.2s ease'
  },
  eyeButton: {
    position: 'absolute',
    right: '12px',
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    color: '#6B7280',
    fontSize: '18px',
    padding: '4px'
  },
  helpText: {
    fontSize: '12px',
    color: '#6B7280',
    fontStyle: 'italic',
    marginTop: '4px'
  },
  submitButton: {
    width: '100%',
    padding: '14px',
    borderRadius: '8px',
    border: 'none',
    color: 'white',
    fontSize: '16px',
    fontWeight: '600',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  },
  loadingContent: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px'
  },
  spinner: {
    animation: 'spin 1s linear infinite'
  },
  actionButtons: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr 1fr',
    gap: '8px',
    marginTop: '8px'
  },
  setupButton: {
    padding: '8px 12px',
    borderRadius: '6px',
    border: '2px solid #10B981',
    backgroundColor: 'white',
    color: '#10B981',
    fontSize: '12px',
    cursor: 'pointer',
    fontWeight: '500',
    transition: 'all 0.2s ease'
  },
  resetButton: {
    padding: '8px 12px',
    borderRadius: '6px',
    border: '2px solid #F59E0B',
    backgroundColor: 'white',
    color: '#F59E0B',
    fontSize: '12px',
    cursor: 'pointer',
    fontWeight: '500',
    transition: 'all 0.2s ease'
  },
  configButton: {
    padding: '8px 12px',
    borderRadius: '6px',
    border: '2px solid #6366F1',
    backgroundColor: 'white',
    color: '#6366F1',
    fontSize: '12px',
    cursor: 'pointer',
    fontWeight: '500',
    transition: 'all 0.2s ease'
  },
  message: {
    padding: '12px 16px',
    borderRadius: '8px',
    fontSize: '14px',
    textAlign: 'center',
    border: '1px solid',
    marginTop: '16px',
    lineHeight: '1.4'
  },
  helpSection: {
    backgroundColor: '#F8FAFC',
    padding: '20px',
    borderRadius: '8px',
    marginTop: '24px'
  },
  helpTitle: {
    fontSize: '16px',
    fontWeight: '600',
    color: '#374151',
    margin: '0 0 12px 0'
  },
  quickFixes: {
    display: 'flex',
    flexDirection: 'column',
    gap: '8px',
    fontSize: '14px',
    color: '#4B5563'
  },
  footerSection: {
    textAlign: 'center',
    marginTop: '20px',
    paddingTop: '20px',
    borderTop: '1px solid #E5E7EB'
  },
  footerText: {
    fontSize: '12px',
    color: '#6B7280',
    margin: 0
  }
};

// Add CSS animation for spinner
const styleSheet = document.createElement("style");
styleSheet.type = "text/css";
styleSheet.innerText = `
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
`;
document.head.appendChild(styleSheet);

export default LoginPageEmployee;
