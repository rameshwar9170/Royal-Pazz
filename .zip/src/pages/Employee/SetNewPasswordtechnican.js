import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, db } from '../../firebase/config';
import { ref, update, get } from 'firebase/database';
import { updatePassword, reauthenticateWithCredential, EmailAuthProvider, onAuthStateChanged } from 'firebase/auth';
import { FaEye, FaEyeSlash, FaLock, FaCheckCircle, FaExclamationTriangle, FaSpinner } from 'react-icons/fa';

const SetNewPasswordtechnican = () => {
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState('');
  const [validationErrors, setValidationErrors] = useState([]);
  const [employeeData, setEmployeeData] = useState(null);
  const [authInitialized, setAuthInitialized] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  
  const navigate = useNavigate();

  useEffect(() => {
    console.log('🔧 SetNewPasswordtechnician component mounted');
    
    // Listen to authentication state changes
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      console.log('🔐 Auth state changed:', user ? 'User found' : 'No user');
      setCurrentUser(user);
      setAuthInitialized(true);
      
      if (!user) {
        console.log('❌ No authenticated user found');
        setError('❌ Authentication session expired. Please login again.');
        setTimeout(() => navigate('/employee-login'), 3000);
        return;
      }
      
      // Get employee data from localStorage
      const storedEmployeeData = localStorage.getItem('employeeData');
      if (!storedEmployeeData) {
        console.log('❌ No employee data in localStorage');
        setError('❌ Session data missing. Please login again.');
        setTimeout(() => navigate('/employee-login'), 3000);
        return;
      }

      try {
        const parsedData = JSON.parse(storedEmployeeData);
        console.log('✅ Employee data loaded:', parsedData.name, 'Role:', parsedData.role);
        
        // Verify this is a technician
        if (parsedData.role !== 'Technician') {
          console.log('❌ User is not a technician:', parsedData.role);
          setError('❌ This page is only for Technician accounts.');
          setTimeout(() => navigate('/employee-login'), 3000);
          return;
        }
        
        setEmployeeData(parsedData);
        
        // Check if user needs to set password
        if (parsedData.firstTime === false) {
          console.log('🔄 User already set password, redirecting to dashboard');
          navigate('/employee-dashboard', { replace: true });
        }
      } catch (parseError) {
        console.error('❌ Error parsing employee data:', parseError);
        setError('❌ Invalid session data. Please login again.');
        setTimeout(() => navigate('/employee-login'), 3000);
      }
    });

    return () => unsubscribe();
  }, [navigate]);

  // Show loading while auth initializes
  if (!authInitialized) {
    return (
      <div style={styles.container}>
        <div style={styles.loadingContainer}>
          <FaSpinner style={styles.loadingSpinner} />
          <h3 style={styles.loadingText}>Initializing...</h3>
          <p style={styles.loadingSubtext}>Please wait while we verify your session</p>
        </div>
      </div>
    );
  }

  // Password validation function
  const validatePassword = (password) => {
    const errors = [];
    const strength = { score: 0, level: '' };

    if (password.length < 8) {
      errors.push('Password must be at least 8 characters long');
    } else {
      strength.score += 1;
    }

    if (!/[a-z]/.test(password)) {
      errors.push('Password must contain at least one lowercase letter');
    } else {
      strength.score += 1;
    }

    if (!/[A-Z]/.test(password)) {
      errors.push('Password must contain at least one uppercase letter');
    } else {
      strength.score += 1;
    }

    if (!/\d/.test(password)) {
      errors.push('Password must contain at least one number');
    } else {
      strength.score += 1;
    }

    if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
      errors.push('Password must contain at least one special character (!@#$%^&*...)');
    } else {
      strength.score += 1;
    }

    // Determine strength level
    if (strength.score <= 2) {
      strength.level = 'Weak';
    } else if (strength.score <= 3) {
      strength.level = 'Fair';
    } else if (strength.score <= 4) {
      strength.level = 'Good';
    } else {
      strength.level = 'Strong';
    }

    setValidationErrors(errors);
    setPasswordStrength(strength.level);
  };

  const handleNewPasswordChange = (e) => {
    const value = e.target.value;
    setNewPassword(value);
    if (value) {
      validatePassword(value);
    } else {
      setValidationErrors([]);
      setPasswordStrength('');
    }
    setError('');
  };

  const handleConfirmPasswordChange = (e) => {
    setConfirmPassword(e.target.value);
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    console.log('🔐 Starting password update process for technician...');

    // Validation
    if (!newPassword || !confirmPassword) {
      setError('❌ Please fill in both password fields');
      setLoading(false);
      return;
    }

    if (newPassword !== confirmPassword) {
      setError('❌ Passwords do not match');
      setLoading(false);
      return;
    }

    if (validationErrors.length > 0) {
      setError('❌ Please fix all password requirements');
      setLoading(false);
      return;
    }

    if (newPassword.length < 8) {
      setError('❌ Password must be at least 8 characters long');
      setLoading(false);
      return;
    }

    try {
      if (!currentUser || !employeeData) {
        setError('❌ Authentication error. Please login again.');
        setLoading(false);
        return;
      }

      console.log('🔐 Updating password for technician:', currentUser.email);

      // Re-authenticate user with mobile number (current password)
      const credential = EmailAuthProvider.credential(
        currentUser.email, 
        employeeData.mobile // Current password is mobile number
      );

      try {
        console.log('🔄 Re-authenticating technician with mobile number...');
        await reauthenticateWithCredential(currentUser, credential);
        console.log('✅ Re-authentication successful');
      } catch (reAuthError) {
        console.error('❌ Re-authentication failed:', reAuthError);
        
        // More specific error handling for re-authentication
        let reAuthErrorMessage = '❌ Re-authentication failed. ';
        switch (reAuthError.code) {
          case 'auth/wrong-password':
            reAuthErrorMessage += 'Mobile number verification failed. Please login again.';
            break;
          case 'auth/user-mismatch':
            reAuthErrorMessage += 'User credentials mismatch. Please login again.';
            break;
          case 'auth/user-not-found':
            reAuthErrorMessage += 'User not found. Please login again.';
            break;
          case 'auth/requires-recent-login':
            reAuthErrorMessage += 'Please logout and login again.';
            break;
          default:
            reAuthErrorMessage += reAuthError.message;
        }
        
        setError(reAuthErrorMessage);
        setLoading(false);
        
        // Redirect to login after 3 seconds if re-auth fails
        setTimeout(() => navigate('/employee-login'), 3000);
        return;
      }

      // Update password in Firebase Auth
      console.log('🔄 Updating Firebase password for technician...');
      await updatePassword(currentUser, newPassword);
      console.log('✅ Firebase password updated successfully');

      // Update technician record in database (using mobile number as ID)
      if (employeeData.mobile) {
        console.log('🔄 Updating technician record in database...');
        await update(ref(db, `HTAMS/company/Employees/${employeeData.mobile}`), {
          firstTime: false,
          passwordSetAt: new Date().toISOString(),
          lastLoginAt: new Date().toISOString()
        });
        console.log('✅ Technician record updated');
      }

      // Update localStorage
      const updatedEmployeeData = {
        ...employeeData,
        firstTime: false,
        passwordSetAt: new Date().toISOString()
      };
      localStorage.setItem('employeeData', JSON.stringify(updatedEmployeeData));
      console.log('✅ localStorage updated');

      setError('✅ Password updated successfully! Redirecting to dashboard...');
      
      // Redirect to employee dashboard
      setTimeout(() => {
        navigate('/employee-dashboard', { replace: true });
      }, 2000);

    } catch (error) {
      console.error('❌ Password update error:', error);
      
      let errorMessage = '❌ Failed to update password. ';
      switch (error.code) {
        case 'auth/weak-password':
          errorMessage += 'Password is too weak.';
          break;
        case 'auth/requires-recent-login':
          errorMessage += 'Please logout and login again.';
          break;
        case 'auth/user-not-found':
          errorMessage += 'User not found. Please login again.';
          break;
        case 'auth/network-request-failed':
          errorMessage += 'Network error. Check your connection.';
          break;
        case 'auth/operation-not-allowed':
          errorMessage += 'Operation not allowed. Contact admin.';
          break;
        default:
          errorMessage += error.message;
      }
      
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const getStrengthColor = (strength) => {
    switch (strength) {
      case 'Weak': return '#ef4444';
      case 'Fair': return '#f97316';
      case 'Good': return '#eab308';
      case 'Strong': return '#22c55e';
      default: return '#6b7280';
    }
  };

  // Show error state if no employee data or not a technician
  if (!employeeData) {
    return (
      <div style={styles.container}>
        <div style={styles.errorContainer}>
          <FaExclamationTriangle style={styles.errorIcon} />
          <h3 style={styles.errorTitle}>Session Error</h3>
          <p style={styles.errorText}>
            Your session has expired or is invalid.
            <br />
            Redirecting to login page...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      <div style={styles.formContainer}>
        <div style={styles.header}>
          <FaLock style={styles.headerIcon} />
          <h2 style={styles.title}>Set New Password - Technician</h2>
          <p style={styles.subtitle}>
            Create a strong password for your technician account
            <br/><strong>{employeeData.name}</strong> ({employeeData.email})
            <br/><span style={styles.roleIndicator}>🔧 Role: {employeeData.role}</span>
          </p>
        </div>

        <form onSubmit={handleSubmit} style={styles.form}>
          {/* New Password Field */}
          <div style={styles.inputGroup}>
            <label style={styles.label}>
              <FaLock style={styles.labelIcon} />
              New Password *
            </label>
            <div style={styles.passwordInputWrapper}>
              <input
                type={showNewPassword ? 'text' : 'password'}
                value={newPassword}
                onChange={handleNewPasswordChange}
                placeholder="Enter your new password"
                required
                style={styles.passwordInput}
                disabled={loading}
              />
              <button
                type="button"
                onClick={() => setShowNewPassword(!showNewPassword)}
                style={styles.eyeButton}
                disabled={loading}
              >
                {showNewPassword ? <FaEyeSlash /> : <FaEye />}
              </button>
            </div>
            
            {/* Password Strength Indicator */}
            {newPassword && (
              <div style={styles.strengthIndicator}>
                <div style={styles.strengthBar}>
                  <div 
                    style={{
                      ...styles.strengthFill,
                      width: `${(validationErrors.length === 0 ? 100 : Math.max(20, (5 - validationErrors.length) * 20))}%`,
                      backgroundColor: getStrengthColor(passwordStrength)
                    }}
                  />
                </div>
                <span style={{...styles.strengthText, color: getStrengthColor(passwordStrength)}}>
                  {passwordStrength}
                </span>
              </div>
            )}
          </div>

          {/* Confirm Password Field */}
          <div style={styles.inputGroup}>
            <label style={styles.label}>
              <FaLock style={styles.labelIcon} />
              Confirm Password *
            </label>
            <div style={styles.passwordInputWrapper}>
              <input
                type={showConfirmPassword ? 'text' : 'password'}
                value={confirmPassword}
                onChange={handleConfirmPasswordChange}
                placeholder="Re-enter your new password"
                required
                style={{
                  ...styles.passwordInput,
                  borderColor: confirmPassword && newPassword !== confirmPassword ? '#ef4444' : '#e5e7eb'
                }}
                disabled={loading}
              />
              <button
                type="button"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                style={styles.eyeButton}
                disabled={loading}
              >
                {showConfirmPassword ? <FaEyeSlash /> : <FaEye />}
              </button>
            </div>
            
            {/* Password Match Indicator */}
            {confirmPassword && (
              <div style={styles.matchIndicator}>
                {newPassword === confirmPassword ? (
                  <span style={styles.matchSuccess}>
                    <FaCheckCircle style={styles.matchIcon} />
                    Passwords match
                  </span>
                ) : (
                  <span style={styles.matchError}>
                    <FaExclamationTriangle style={styles.matchIcon} />
                    Passwords do not match
                  </span>
                )}
              </div>
            )}
          </div>

          {/* Password Requirements */}
          {validationErrors.length > 0 && (
            <div style={styles.requirementsContainer}>
              <h4 style={styles.requirementsTitle}>Password Requirements:</h4>
              <ul style={styles.requirementsList}>
                {validationErrors.map((error, index) => (
                  <li key={index} style={styles.requirementItem}>
                    <FaExclamationTriangle style={styles.requirementIcon} />
                    {error}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Success Requirements */}
          {newPassword && validationErrors.length === 0 && (
            <div style={styles.successContainer}>
              <span style={styles.successText}>
                <FaCheckCircle style={styles.successIcon} />
                Password meets all requirements
              </span>
            </div>
          )}

          {/* Error Message */}
          {error && (
            <div style={{
              ...styles.message,
              backgroundColor: error.includes('✅') ? '#d1fae5' : '#fee2e2',
              borderColor: error.includes('✅') ? '#10b981' : '#ef4444',
              color: error.includes('✅') ? '#065f46' : '#b91c1c'
            }}>
              {error}
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading || validationErrors.length > 0 || !newPassword || !confirmPassword || newPassword !== confirmPassword}
            style={{
              ...styles.submitButton,
              backgroundColor: loading || validationErrors.length > 0 || !newPassword || !confirmPassword || newPassword !== confirmPassword 
                ? '#9ca3af' : '#10b981'
            }}
          >
            {loading ? (
              <span style={styles.loadingContent}>
                <FaSpinner style={styles.spinner} />
                Updating Password...
              </span>
            ) : '🔐 Set New Password'}
          </button>
        </form>

        {/* Help Section */}
        <div style={styles.helpSection}>
          <h4>💡 Tips for a Strong Password:</h4>
          <ul style={styles.helpList}>
            <li>Use a mix of uppercase and lowercase letters</li>
            <li>Include numbers and special characters</li>
            <li>Avoid common words or personal information</li>
            <li>Make it at least 8 characters long</li>
          </ul>
        </div>

        {/* Technician-specific help */}
        <div style={styles.technicianHelpSection}>
          <h4>🔧 For Technicians:</h4>
          <ul style={styles.helpList}>
            <li>Your password will be used to access technical systems</li>
            <li>Keep your credentials secure and don't share them</li>
            <li>Contact IT support if you face any issues</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

const styles = {
  container: {
    minHeight: '100vh',
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '20px',
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
  },
  loadingContainer: {
    backgroundColor: 'white',
    borderRadius: '16px',
    boxShadow: '0 10px 25px rgba(0,0,0,0.15)',
    padding: '60px 40px',
    textAlign: 'center',
    maxWidth: '400px'
  },
  loadingSpinner: {
    fontSize: '3rem',
    color: '#2563EB',
    animation: 'spin 1s linear infinite',
    marginBottom: '20px'
  },
  loadingText: {
    fontSize: '24px',
    fontWeight: '600',
    color: '#1f2937',
    margin: '0 0 8px 0'
  },
  loadingSubtext: {
    fontSize: '14px',
    color: '#6b7280',
    margin: 0
  },
  errorContainer: {
    backgroundColor: 'white',
    borderRadius: '16px',
    boxShadow: '0 10px 25px rgba(0,0,0,0.15)',
    padding: '60px 40px',
    textAlign: 'center',
    maxWidth: '400px'
  },
  errorIcon: {
    fontSize: '3rem',
    color: '#ef4444',
    marginBottom: '20px'
  },
  errorTitle: {
    fontSize: '24px',
    fontWeight: '600',
    color: '#1f2937',
    margin: '0 0 12px 0'
  },
  errorText: {
    fontSize: '16px',
    color: '#6b7280',
    margin: 0,
    lineHeight: '1.5'
  },
  formContainer: {
    backgroundColor: 'white',
    borderRadius: '16px',
    boxShadow: '0 10px 25px rgba(0,0,0,0.15)',
    padding: '40px',
    width: '100%',
    maxWidth: '500px'
  },
  header: {
    textAlign: 'center',
    marginBottom: '30px'
  },
  headerIcon: {
    fontSize: '3rem',
    color: '#10b981',
    marginBottom: '16px'
  },
  title: {
    fontSize: '28px',
    fontWeight: '700',
    color: '#1f2937',
    margin: '0 0 8px 0'
  },
  subtitle: {
    fontSize: '16px',
    color: '#6b7280',
    margin: 0,
    lineHeight: '1.5'
  },
  roleIndicator: {
    fontSize: '14px',
    color: '#10b981',
    fontWeight: '600'
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '24px'
  },
  inputGroup: {
    display: 'flex',
    flexDirection: 'column',
    gap: '8px'
  },
  label: {
    fontSize: '14px',
    fontWeight: '600',
    color: '#374151',
    display: 'flex',
    alignItems: 'center',
    gap: '8px'
  },
  labelIcon: {
    fontSize: '14px',
    color: '#6b7280'
  },
  passwordInputWrapper: {
    position: 'relative',
    display: 'flex',
    alignItems: 'center'
  },
  passwordInput: {
    width: '100%',
    padding: '12px 50px 12px 16px',
    border: '2px solid #e5e7eb',
    borderRadius: '8px',
    fontSize: '16px',
    boxSizing: 'border-box',
    transition: 'border-color 0.2s ease'
  },
  eyeButton: {
    position: 'absolute',
    right: '12px',
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    color: '#6b7280',
    fontSize: '18px',
    padding: '4px'
  },
  strengthIndicator: {
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
    marginTop: '8px'
  },
  strengthBar: {
    flex: 1,
    height: '6px',
    backgroundColor: '#e5e7eb',
    borderRadius: '3px',
    overflow: 'hidden'
  },
  strengthFill: {
    height: '100%',
    transition: 'all 0.3s ease',
    borderRadius: '3px'
  },
  strengthText: {
    fontSize: '12px',
    fontWeight: '600',
    minWidth: '60px',
    textAlign: 'right'
  },
  matchIndicator: {
    marginTop: '8px'
  },
  matchSuccess: {
    color: '#10b981',
    fontSize: '14px',
    display: 'flex',
    alignItems: 'center',
    gap: '6px'
  },
  matchError: {
    color: '#ef4444',
    fontSize: '14px',
    display: 'flex',
    alignItems: 'center',
    gap: '6px'
  },
  matchIcon: {
    fontSize: '12px'
  },
  requirementsContainer: {
    backgroundColor: '#fef2f2',
    border: '1px solid #fecaca',
    borderRadius: '8px',
    padding: '16px'
  },
  requirementsTitle: {
    fontSize: '14px',
    fontWeight: '600',
    color: '#b91c1c',
    margin: '0 0 12px 0'
  },
  requirementsList: {
    margin: 0,
    paddingLeft: '0',
    listStyle: 'none'
  },
  requirementItem: {
    color: '#dc2626',
    fontSize: '13px',
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    marginBottom: '6px'
  },
  requirementIcon: {
    fontSize: '12px',
    flexShrink: 0
  },
  successContainer: {
    backgroundColor: '#d1fae5',
    border: '1px solid #a7f3d0',
    borderRadius: '8px',
    padding: '12px'
  },
  successText: {
    color: '#065f46',
    fontSize: '14px',
    fontWeight: '500',
    display: 'flex',
    alignItems: 'center',
    gap: '8px'
  },
  successIcon: {
    fontSize: '14px'
  },
  message: {
    padding: '12px 16px',
    borderRadius: '8px',
    fontSize: '14px',
    textAlign: 'center',
    border: '1px solid'
  },
  submitButton: {
    width: '100%',
    padding: '14px',
    borderRadius: '8px',
    border: 'none',
    color: 'white',
    fontSize: '16px',
    fontWeight: '600',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  },
  loadingContent: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px'
  },
  spinner: {
    animation: 'spin 1s linear infinite'
  },
  helpSection: {
    backgroundColor: '#f8fafc',
    padding: '20px',
    borderRadius: '8px',
    marginTop: '24px'
  },
  technicianHelpSection: {
    backgroundColor: '#e8f5e8',
    padding: '20px',
    borderRadius: '8px',
    marginTop: '16px',
    border: '1px solid #d1fae5'
  },
  helpList: {
    margin: '12px 0 0 0',
    paddingLeft: '20px',
    fontSize: '14px',
    color: '#4b5563',
    lineHeight: '1.6'
  }
};

// Add CSS animation for spinner
const styleSheet = document.createElement("style");
styleSheet.type = "text/css";
styleSheet.innerText = `
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
`;
document.head.appendChild(styleSheet);

export default SetNewPasswordtechnican;
