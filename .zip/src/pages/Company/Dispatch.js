import React, { useEffect, useMemo, useState } from 'react';
import { ref, onValue, update } from 'firebase/database';
import { db } from '../../firebase/config';
import { FiPackage, FiSearch, FiUser, FiPhone, FiCheck, FiTruck, FiX } from 'react-icons/fi';

const Dispatch = () => {
  const [orders, setOrders] = useState([]);
  const [technicians, setTechnicians] = useState([]);
  const [search, setSearch] = useState('');
  // Local edit state per orderId
  const [edits, setEdits] = useState({});
  const [saving, setSaving] = useState({});

  // Load all orders
  useEffect(() => {
    const ordersRef = ref(db, 'HTAMS/orders');
    const unsub = onValue(ordersRef, (snap) => {
      const val = snap.val() || {};
      const list = Object.entries(val).map(([id, o]) => ({ id, ...(o || {}) }));
      setOrders(list);
    });
    return () => {
      if (typeof unsub === 'function') unsub();
    };
  }, []);

  // Load technicians
  useEffect(() => {
    const employeesRef = ref(db, 'HTAMS/company/Employees');
    const unsub = onValue(employeesRef, (snap) => {
      const val = snap.val() || {};
      const list = Object.entries(val)
        .map(([id, emp]) => ({ id, ...(emp || {}) }))
        .filter((e) => e.role?.toLowerCase?.() === 'technician');
      setTechnicians(list);
    });
    return () => {
      if (typeof unsub === 'function') unsub();
    };
  }, []);

  const confirmedOrders = useMemo(() => {
    const q = search.trim().toLowerCase();
    return orders
      .filter((o) => (o.status || '').toLowerCase() === 'confirmed')
      .filter((o) => {
        if (!q) return true;
        const hay = `${o.customerName || ''} ${o.customerPhone || ''} ${o.productName || ''}`.toLowerCase();
        return hay.includes(q);
      });
  }, [orders, search]);

  const calculateAmount = (order) => {
    if (typeof order.totalAmount === 'number') return order.totalAmount;
    if (order.amount) return order.amount;
    if (order.price) return order.price;
    if (Array.isArray(order.items)) {
      return order.items.reduce((acc, it) => acc + Number(it.totalPrice || (it.price || 0) * (it.quantity || 0)), 0);
    }
    if (order.quantity && order.unitPrice) return order.quantity * order.unitPrice;
    return 0;
  };

  const getRowEdit = (order) => {
    const current = edits[order.id] || {};
    return {
      status: current.status ?? order.status ?? 'confirmed',
      technicianId: current.technicianId ?? order.assignedTechnicianId ?? '',
    };
  };

  const onChangeEdit = (orderId, field, value) => {
    setEdits((prev) => ({
      ...prev,
      [orderId]: {
        ...(prev[orderId] || {}),
        [field]: value,
      },
    }));
  };

  const saveRow = async (order) => {
    const { status, technicianId } = getRowEdit(order);
    const tech = technicians.find((t) => t.id === technicianId);

    const updates = {
      status: (status || '').toLowerCase(),
      assignedTechnicianId: tech?.id,
      assignedTechnicianName: tech?.name,
      assignedTechnicianMobile: tech?.mobile,
    };
    // add timestamp for status
    if (updates.status) {
      updates[`${updates.status}At`] = new Date().toISOString();
    }
    // remove undefined
    Object.keys(updates).forEach((k) => updates[k] === undefined && delete updates[k]);

    try {
      setSaving((s) => ({ ...s, [order.id]: true }));
      await update(ref(db, `HTAMS/orders/${order.id}`), updates);
    } catch (e) {
      console.error('Failed to update order', order.id, e);
      alert('Failed to update order. Please try again.');
    } finally {
      setSaving((s) => ({ ...s, [order.id]: false }));
    }
  };

  const renderProducts = (o) => {
    if (Array.isArray(o.items) && o.items.length > 0) {
      const names = o.items.map((it) => it.productName || it.name).filter(Boolean);
      return names.length > 1 ? `${names[0]} +${names.length - 1} more` : (names[0] || '-');
    }
    return o.productName || '-';
  };

  return (
    <div className="dispatch-container">
      <div className="page-header">
        <div className="header-content">
          <h1 className="page-title">
            <FiPackage className="title-icon" />
            Dispatch Management
          </h1>
          <p className="page-subtitle">Manage confirmed orders, assign technicians and move status</p>
        </div>
      </div>

      <div className="controls-section">
        <div className="search-container">
          <FiSearch className="search-icon" />
          <input
            type="text"
            placeholder="Search confirmed orders..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="search-input"
          />
        </div>
        <div className="summary">Total Confirmed: {confirmedOrders.length}</div>
      </div>

      <div className="table-wrapper">
        <table className="orders-table">
          <thead>
            <tr>
              <th>Sr.No</th>
              <th>Customer</th>
              <th>Products</th>
              <th>Amount</th>
              <th>Expected</th>
              <th>Technician</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {confirmedOrders.map((o, idx) => {
              const edit = getRowEdit(o);
              return (
                <tr key={o.id}>
                  <td>{idx + 1}</td>
                  <td className="customer-cell">
                    <div className="cust-name"><FiUser /> {o.customerName || '-'}</div>
                    <div className="cust-phone"><FiPhone /> {o.customerPhone || '-'}</div>
                  </td>
                  <td>{renderProducts(o)}</td>
                  <td>₹{calculateAmount(o).toLocaleString()}</td>
                  <td>{o.expectedDate || '-'}</td>
                  <td>
                    <select
                      className="control-input"
                      value={edit.technicianId}
                      onChange={(e) => onChangeEdit(o.id, 'technicianId', e.target.value)}
                    >
                      <option value="">-- Select Technician --</option>
                      {technicians.map((t) => (
                        <option key={t.id} value={t.id}>
                          {t.name || t.userId || t.mobile} {t.mobile ? `(${t.mobile})` : ''}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td>
                    <select
                      className="control-input"
                      value={edit.status}
                      onChange={(e) => onChangeEdit(o.id, 'status', e.target.value)}
                    >
                      <option value="confirmed">Confirmed</option>
                      <option value="in-progress">In Progress</option>
                      <option value="completed">Completed</option>
                      <option value="cancelled">Cancelled</option>
                    </select>
                  </td>
                  <td>
                    <button
                      className="save-btn"
                      onClick={() => saveRow(o)}
                      disabled={!!saving[o.id]}
                      title="Save changes"
                    >
                      {saving[o.id] ? 'Saving...' : 'Save'}
                    </button>
                  </td>
                </tr>
              );
            })}
            {confirmedOrders.length === 0 && (
              <tr>
                <td colSpan="8" style={{ textAlign: 'center', color: '#64748b' }}>No confirmed orders</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <style jsx>{`
        .dispatch-container {
          font-family: 'Inter', sans-serif;
          background: #f8fafc;
          min-height: 100vh;
          padding: 16px;
        }
        .page-header {
          background: white;
          border-radius: 16px;
          padding: 20px 24px;
          margin-bottom: 16px;
          box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        .page-title {
          display: flex;
          align-items: center;
          gap: 10px;
          margin: 0;
          font-weight: 700;
          color: #1e293b;
        }
        .title-icon { color: #6366f1; }
        .page-subtitle { margin: 6px 0 0; color: #64748b; }
        .controls-section { display: flex; gap: 16px; align-items: center; margin-bottom: 16px; }
        .search-container { position: relative; max-width: 360px; width: 100%; }
        .search-icon { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: #94a3b8; }
        .search-input { width: 100%; padding: 10px 12px 10px 38px; border: 2px solid #e2e8f0; border-radius: 10px; outline: none; }
        .search-input:focus { border-color: #6366f1; box-shadow: 0 0 0 3px rgba(99,102,241,0.1); }
        .summary { color: #374151; font-weight: 600; }
        .table-wrapper { background: white; border-radius: 16px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border: 1px solid #e2e8f0; }
        .orders-table { width: 100%; border-collapse: collapse; min-width: 1000px; }
        .orders-table th { background: #1f2937; color: white; text-align: left; padding: 12px 14px; font-size: 0.85rem; position: sticky; top: 0; }
        .orders-table td { padding: 12px 14px; border-bottom: 1px solid #e5e7eb; }
        .customer-cell .cust-name, .customer-cell .cust-phone { display: flex; gap: 6px; align-items: center; color: #374151; }
        .control-input { padding: 8px 10px; border: 2px solid #e2e8f0; border-radius: 8px; outline: none; min-width: 200px; }
        .control-input:focus { border-color: #6366f1; box-shadow: 0 0 0 3px rgba(99,102,241,0.1); }
        .save-btn { background: #10b981; color: white; border: none; padding: 10px 14px; border-radius: 8px; font-weight: 600; cursor: pointer; }
        .save-btn:disabled { background: #a7f3d0; cursor: not-allowed; }
        @media (max-width: 992px) { .orders-table { min-width: 800px; } }
      `}</style>
    </div>
  );
};

export default Dispatch;

