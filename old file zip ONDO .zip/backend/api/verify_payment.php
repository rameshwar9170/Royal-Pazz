<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

// For testing without database - remove this when you have database setup
$testMode = true;

if ($testMode) {
    // Get posted data
    $data = json_decode(file_get_contents("php://input"));
    
    if(!empty($data->razorpay_payment_id) && !empty($data->razorpay_order_id) && !empty($data->razorpay_signature)) {
        // Simulate successful payment verification
        $invoiceNumber = 'INV' . date('Ymd') . rand(1000, 9999);
        
        http_response_code(200);
        echo json_encode([
            "message" => "Payment verified successfully.",
            "order_id" => rand(1, 1000),
            "invoice_id" => rand(1, 1000),
            "invoice_number" => $invoiceNumber,
            "pdf_filename" => "invoice_" . $invoiceNumber . ".pdf",
            "status" => "success"
        ]);
    } else {
        http_response_code(400);
        echo json_encode(["message" => "Payment verification data is incomplete."]);
    }
    exit;
}

// Original database code (uncomment when database is ready)
/*
include_once '../config/database.php';
include_once '../config/razorpay.php';
include_once '../models/Order.php';
include_once '../models/Invoice.php';

$database = new Database();
$db = $database->getConnection();

$order = new Order($db);
$invoice = new Invoice($db);
$razorpay = new RazorpayConfig();

// Get posted data
$data = json_decode(file_get_contents("php://input"));

if(!empty($data->razorpay_payment_id) && !empty($data->razorpay_order_id) && !empty($data->razorpay_signature)) {
    try {
        // Verify payment signature
        $attributes = [
            'razorpay_order_id' => $data->razorpay_order_id,
            'razorpay_payment_id' => $data->razorpay_payment_id,
            'razorpay_signature' => $data->razorpay_signature
        ];

        $razorpay->getApi()->utility->verifyPaymentSignature($attributes);

        // Get order by razorpay_order_id
        $order->razorpay_order_id = $data->razorpay_order_id;
        if($order->getByRazorpayOrderId()) {
            // Update order status
            $order->status = 'paid';
            $order->razorpay_payment_id = $data->razorpay_payment_id;
            $order->razorpay_signature = $data->razorpay_signature;

            if($order->updatePaymentStatus()) {
                // Generate invoice
                $invoice->order_id = $order->id;
                $invoice->customer_name = isset($data->customer_name) ? $data->customer_name : 'Customer';
                $invoice->customer_email = isset($data->customer_email) ? $data->customer_email : '';
                $invoice->customer_phone = isset($data->customer_phone) ? $data->customer_phone : '';
                $invoice->billing_address = $order->shipping_address;
                $invoice->items = $order->items;
                
                // Calculate amounts
                $items = json_decode($order->items, true);
                $subtotal = 0;
                foreach($items as $item) {
                    $subtotal += $item['price'] * $item['quantity'];
                }
                
                $invoice->subtotal = $subtotal;
                $invoice->tax_amount = $subtotal * 0.18; // 18% GST
                $invoice->total_amount = $order->total_amount;

                if($invoice->create()) {
                    // Generate PDF
                    $pdfFilename = $invoice->generatePDF();

                    http_response_code(200);
                    echo json_encode([
                        "message" => "Payment verified successfully.",
                        "order_id" => $order->id,
                        "invoice_id" => $invoice->id,
                        "invoice_number" => $invoice->invoice_number,
                        "pdf_filename" => $pdfFilename,
                        "status" => "success"
                    ]);
                } else {
                    http_response_code(500);
                    echo json_encode(["message" => "Payment verified but invoice generation failed."]);
                }
            } else {
                http_response_code(500);
                echo json_encode(["message" => "Payment verified but order update failed."]);
            }
        } else {
            http_response_code(404);
            echo json_encode(["message" => "Order not found."]);
        }
    } catch(Exception $e) {
        http_response_code(400);
        echo json_encode([
            "message" => "Payment verification failed.",
            "error" => $e->getMessage()
        ]);
    }
} else {
    http_response_code(400);
    echo json_encode(["message" => "Payment verification data is incomplete."]);
}
*/
?>
