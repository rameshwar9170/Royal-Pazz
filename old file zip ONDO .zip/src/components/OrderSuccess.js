import React from 'react';
import { CheckCircle, Download, FileText } from 'lucide-react';

const OrderSuccess = ({ orderData, onDownloadInvoice, onContinueShopping }) => {
    const handleDownloadInvoice = () => {
        if (orderData.invoice_id) {
            const downloadUrl = `http://localhost:8000/api/download_invoice.php?invoice_id=${orderData.invoice_id}`;
            window.open(downloadUrl, '_blank');
        }
    };

    return (
        <div className="max-w-md mx-auto bg-white rounded-lg shadow-lg p-6 text-center">
            <div className="mb-6">
                <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <h2 className="text-2xl font-bold text-gray-800 mb-2">Payment Successful!</h2>
                <p className="text-gray-600">Your order has been placed successfully</p>
            </div>

            <div className="bg-gray-50 rounded-lg p-4 mb-6">
                <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                        <span className="text-gray-600">Order ID:</span>
                        <span className="font-medium">#{orderData.order_id}</span>
                    </div>
                    {orderData.invoice_number && (
                        <div className="flex justify-between">
                            <span className="text-gray-600">Invoice Number:</span>
                            <span className="font-medium">{orderData.invoice_number}</span>
                        </div>
                    )}
                    <div className="flex justify-between">
                        <span className="text-gray-600">Payment ID:</span>
                        <span className="font-medium text-xs">{orderData.payment_id}</span>
                    </div>
                </div>
            </div>

            <div className="space-y-3">
                {orderData.invoice_id && (
                    <button
                        onClick={handleDownloadInvoice}
                        className="w-full flex items-center justify-center gap-2 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors"
                    >
                        <Download className="w-4 h-4" />
                        Download Invoice
                    </button>
                )}

                <button
                    onClick={onContinueShopping}
                    className="w-full bg-gray-200 text-gray-800 py-2 px-4 rounded-lg hover:bg-gray-300 transition-colors"
                >
                    Continue Shopping
                </button>
            </div>

            <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                <div className="flex items-center gap-2 text-blue-700 mb-2">
                    <FileText className="w-4 h-4" />
                    <span className="font-medium">What's Next?</span>
                </div>
                <p className="text-sm text-blue-600">
                    You will receive an order confirmation email shortly. 
                    Your invoice has been generated and can be downloaded above.
                </p>
            </div>
        </div>
    );
};

export default OrderSuccess;
