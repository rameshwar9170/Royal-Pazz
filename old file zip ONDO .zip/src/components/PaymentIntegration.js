import React, { useState } from 'react';

const PaymentIntegration = ({ cartItems, totalAmount, customerDetails, onPaymentSuccess, onPaymentError }) => {
    const [isProcessing, setIsProcessing] = useState(false);

    const loadRazorpayScript = () => {
        return new Promise((resolve) => {
            const script = document.createElement('script');
            script.src = 'https://checkout.razorpay.com/v1/checkout.js';
            script.onload = () => resolve(true);
            script.onerror = () => resolve(false);
            document.body.appendChild(script);
        });
    };

    const createOrder = async (orderData) => {
        try {
            const response = await fetch('http://localhost:4000/api/create_order', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    amount: orderData.totalAmount,
                    currency: 'INR',
                    receipt: orderData.orderId
                })
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            
            if (!data.success) {
                throw new Error(data.error || 'Failed to create order');
            }

            return data.order;
        } catch (error) {
            console.error('Error creating order:', error);
            throw error;
        }
    };

    const verifyPayment = async (paymentData) => {
        try {
            const response = await fetch('http://localhost:4000/api/verify_payment', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    razorpay_payment_id: paymentData.razorpay_payment_id,
                    razorpay_order_id: paymentData.razorpay_order_id,
                    razorpay_signature: paymentData.razorpay_signature,
                    customer_name: customerDetails.name,
                    customer_email: customerDetails.email,
                    customer_phone: customerDetails.phone
                })
            });

            const data = await response.json();
            if (response.ok) {
                return data;
            } else {
                throw new Error(data.message || 'Payment verification failed');
            }
        } catch (error) {
            console.error('Error verifying payment:', error);
            throw error;
        }
    };

    const handlePayment = async () => {
        setIsProcessing(true);
        console.log('Starting payment process...');

        try {
            // Load Razorpay script
            console.log('Loading Razorpay script...');
            const scriptLoaded = await loadRazorpayScript();
            if (!scriptLoaded) {
                throw new Error('Failed to load Razorpay script');
            }
            console.log('Razorpay script loaded successfully');

            // Create order
            console.log('Creating order with data:', {
                items: cartItems,
                total_amount: totalAmount,
                customerDetails
            });
            const orderData = await createOrder({
                totalAmount,
                orderId: `order_${Date.now()}`,
                items: cartItems,
                customerDetails
            });
            console.log('Order created successfully:', orderData);

            // Configure Razorpay options
            const options = {
                key: process.env.REACT_APP_RAZORPAY_KEY_ID || 'rzp_test_R8L2IvxoQ9JlMP',
                amount: totalAmount * 100, // Amount in paise
                currency: 'INR',
                name: 'Royal Pazz',
                description: 'Product Purchase',
                order_id: orderData.id,
                handler: async function (response) {
                    console.log('Payment successful:', response);
                    try {
                        setIsProcessing(true);
                        // Verify payment
                        const verificationResult = await verifyPayment(response);
                        console.log('Payment verified:', verificationResult);
                        
                        // Call success callback
                        onPaymentSuccess({
                            ...verificationResult,
                            payment_id: response.razorpay_payment_id,
                            order_id: response.razorpay_order_id
                        });
                        setIsProcessing(false);
                    } catch (error) {
                        console.error('Payment verification failed:', error);
                        onPaymentError(error.message);
                        setIsProcessing(false);
                    }
                },
                prefill: {
                    name: customerDetails.name,
                    email: customerDetails.email,
                    contact: customerDetails.phone
                },
                notes: {
                    address: `${customerDetails.city}, ${customerDetails.state} - ${customerDetails.postal_code}`
                },
                theme: {
                    color: '#6366f1'
                },
                modal: {
                    ondismiss: function() {
                        console.log('Payment modal dismissed');
                        setIsProcessing(false);
                    }
                }
            };

            console.log('Opening Razorpay checkout with options:', options);
            // Open Razorpay checkout
            const razorpay = new window.Razorpay(options);
            razorpay.open();

        } catch (error) {
            console.error('Payment error:', error);
            onPaymentError(error.message || 'Payment failed');
            setIsProcessing(false);
        }
    };

    return (
        <button
            onClick={handlePayment}
            disabled={isProcessing}
            className="w-full bg-indigo-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed"
        >
            {isProcessing ? 'Processing...' : `Pay ₹${totalAmount.toLocaleString()}`}
        </button>
    );
};

export default PaymentIntegration;
