// server.js
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const nodemailer = require('nodemailer');
const Razorpay = require('razorpay');
const crypto = require('crypto');

console.log('EMAIL_USER:', process.env.EMAIL_USER);
console.log('EMAIL_PASS:', process.env.EMAIL_PASS ? '✔ set' : '❌ not set');
console.log('RAZORPAY_KEY_ID:', process.env.RAZORPAY_KEY_ID ? '✔ set' : '❌ not set');

const app = express();
app.use(cors());
app.use(express.json());

// Initialize Razorpay
const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET,
});

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

app.post('/send-email', async (req, res) => {
  const { to, name, loginEmail, loginLink } = req.body;

  const subject = "🎉 Welcome to Panchagiri - Your Agency Account is Ready!";

  const html = `
    <div style="font-family: Arial, sans-serif; padding: 20px; background-color: #f9f9f9;">
      <h2 style="color: #4CAF50;">🎉 Welcome to Panchagiri!</h2>
      <p>Dear <strong>${name}</strong>,</p>
      <p>Congratulations! You have been successfully confirmed as an agency in the <strong>Panchagiri</strong> system.</p>
      
      <p>Here are your login details:</p>
      <ul style="line-height: 1.6;">
        <li><strong>Email:</stro  ng> ${loginEmail}</li>
         <img src="./Public/htams-logo.png" alt="Panchagiri Logo" style="max-width: 150px; margin-bottom: 20px;" />
        <li><strong>Password:</strong> Your phone number (please change it after first login)</li>
      </ul>

      <p>You can log in using the link below:</p>
      <a href="${loginLink}" style="display: inline-block; padding: 10px 20px; background-color: #4CAF50; color: white; text-decoration: none; border-radius: 4px;">Login to HTAMS</a>

      <p>If you have any questions, feel free to contact our support team.</p>

      <hr />
      <p style="font-size: 12px; color: #555;">This is an automated message. Please do not reply.</p>
    </div>
  `;

  try {
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to,
      subject,
      html,
    });

    console.log('✅ Email sent to:', to);
    res.status(200).send({ success: true });
  } catch (error) {
    console.error('❌ Error sending email:', error);
    res.status(500).send({ success: false, error: error.message });
  }
});

// Razorpay API endpoints
app.post('/api/create_order', async (req, res) => {
  try {
    console.log('Received request body:', req.body);
    const { amount, currency = 'INR', receipt } = req.body;
    
    if (!amount || amount <= 0) {
      return res.status(400).json({ success: false, error: 'Invalid amount' });
    }

    const options = {
      amount: amount * 100, // Convert to paise
      currency,
      receipt: receipt || `receipt_${Date.now()}`,
    };

    console.log('Creating Razorpay order with options:', options);
    const order = await razorpay.orders.create(options);
    console.log('Order created successfully:', order);
    
    res.json({ success: true, order });
  } catch (error) {
    console.error('Error creating order:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/verify_payment', async (req, res) => {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;

    const body = razorpay_order_id + "|" + razorpay_payment_id;
    const expectedSignature = crypto
      .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
      .update(body.toString())
      .digest("hex");

    const isAuthentic = expectedSignature === razorpay_signature;

    if (isAuthentic) {
      res.json({ success: true, message: 'Payment verified successfully' });
    } else {
      res.status(400).json({ success: false, message: 'Payment verification failed' });
    }
  } catch (error) {
    console.error('Error verifying payment:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

const PORT = 4000;
app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
  console.log(`📧 Email service available`);
  console.log(`💳 Razorpay payment service available`);
});
