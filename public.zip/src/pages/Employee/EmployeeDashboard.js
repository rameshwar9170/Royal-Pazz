// pages/Employee/EmployeeDashboard.js
import React from 'react';

const EmployeeDashboard = () => {
  return (
    <div style={{ padding: 20 }}>
      <h2>👷‍♂️ Welcome to the Employee Dashboard</h2>
      <p>This is for Technicians or general employees.</p>
      {/* Add more content here */}
    </div>
  );
};

export default EmployeeDashboard;
